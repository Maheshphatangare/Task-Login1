package com.lg.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lg.Entity.User;
import com.lg.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	
	@PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody User user) {
        try {
            User registeredUser = userService.registerUser(user);
            Map<String, String> response = new HashMap<>();
            response.put("message", "User registered successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        try {
            String email = credentials.get("email");
            String password = credentials.get("password");
            User user = userService.findByEmail(email);
            if (userService.validatePassword(password, user.getPassword())) {
                Map<String, String> response = new HashMap<>();
                response.put("message", "Login successful");
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.badRequest().body("Invalid credentials");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
  
//	@GetMapping("/register")
//	public String getregpage(@ModelAttribute("user") UserDto userdto)
// {
//	 return "register";
// }
//  
//  @PostMapping("/register")
//  public String SaveUser(@ModelAttribute("user") UserDto userdto,Model m) {
//	  userService.save(userdto);
//	  m.addAttribute("message","register sucesssfully");
//	  return "register";
//  }
//  @GetMapping("/login")
//  public String login() {
//	  return "login";
//  }
//  @GetMapping("/user-page")
//  public String user() {
//	  return "user";
//  }
//  @GetMapping("/admin-page")
//  public String adminuser() {
//	  return "admin";
//  }
//}
