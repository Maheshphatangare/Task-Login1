package com.lg.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
@ComponentScan(basePackages={"com.lg.repo", "com.lg.controller","com.lg.service","com.lg.config","com.lg.filter"})
@EnableJpaRepositories(basePackages="com.lg.repo")
//@EnableTransactionManagement
@EntityScan(basePackages={"com.lg.Entity"})
@SpringBootApplication
public class LoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginApplication.class, args);
	}

}
